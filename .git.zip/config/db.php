<?php
return [
    'host' => $_ENV['DB_HOST'] ?? 'mysql',
    'port' => $_ENV['DB_PORT'] ?? 3306,
    'dbname' => $_ENV['DB_NAME'] ?? 'workopia',
    'username' => $_ENV['DB_USER'] ?? 'workopia_user',
    'password' => $_ENV['DB_PASSWORD'] ?? 'workopia_password'
];